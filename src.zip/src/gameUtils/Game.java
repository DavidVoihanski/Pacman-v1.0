package gameUtils;

public class Game {

}
