package gameUtils;

import java.io.IOException;

public class MapFactory {
public static Map defaultMapInit() throws IOException {
	return new Map();
}
}
