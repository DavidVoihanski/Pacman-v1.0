package gameUtils;

public class Fruit {

}
