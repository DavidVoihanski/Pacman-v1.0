package algorithm;

public class ShortestPathAlgo {

}
