package GUI;

import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.IOException;


import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import Geom.Point3D;
import gameUtils.Map;
import gameUtils.MapFactory;

public class MyFrame extends JFrame implements MouseListener, ComponentListener {
	private static final long serialVersionUID = 1L;
	private Map gameMap;
	private BufferedImage gameChangingImage;
	public static Point3D lastClicked;
	public static int height;
	public static int width;
	private ImagePanel imagePanel;

	public MyFrame() throws IOException {
		initComponents();
		this.addMouseListener(this);
		this.addComponentListener(this);
	}

//*******component listener*******
	@Override
	public void componentHidden(ComponentEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void componentMoved(ComponentEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void componentResized(ComponentEvent arg0) {
		this.imagePanel.resizeImage(this.getWidth() - 22, this.getHeight() - 79);

	}

	@Override
	public void componentShown(ComponentEvent arg0) {
		// TODO Auto-generated method stub

	}
//*******mouse listener******* 
	@Override
	public void mouseClicked(MouseEvent arg0) {
		width = this.getWidth() - 22;
		height = this.getHeight() - 79;
		lastClicked = new Point3D(arg0.getX(), arg0.getY(), 0);
		try {
			System.out.println("***" + this.gameMap.clickedToAddPoint());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}
//*******private methods*******
	private void initComponents() throws IOException {
		// now building the menu bar and all its features
		JMenuBar menuBar = new JMenuBar();
		// menu first - external "button:
		JMenu mainMenu = new JMenu("Menu");
		mainMenu.setMnemonic(KeyEvent.VK_R);
		// creating subMenus
		JMenu subMenuCustomGame = new JMenu("custom game");
		subMenuCustomGame.setMnemonic(KeyEvent.VK_R);
		JMenu subMenuDefaultGame = new JMenu("default game");
		subMenuDefaultGame.setMnemonic(KeyEvent.VK_R);
		// creating all menuItems for custom game
		JMenuItem chooseMap = new JMenuItem("choose a map");
		chooseMap.setMnemonic(KeyEvent.VK_R);
		subMenuCustomGame.add(chooseMap);
		JMenuItem setMapGpsCoords = new JMenuItem("set the gps coords of the map");
		setMapGpsCoords.setMnemonic(KeyEvent.VK_R);
		subMenuCustomGame.add(setMapGpsCoords);
		mainMenu.add(subMenuCustomGame);
		// creating all menuItems for default game
		JMenu existingGame = new JMenu("play existing game");
		existingGame.setMnemonic(KeyEvent.VK_R);
		JMenuItem loadCsv = new JMenuItem("load CSV file");
		loadCsv.setMnemonic(KeyEvent.VK_R);
		existingGame.add(loadCsv);
		subMenuDefaultGame.add(existingGame);
		JMenu newGame = new JMenu("build your own game");
		newGame.setMnemonic(KeyEvent.VK_R);
		JMenuItem packman = new JMenuItem("add packman");
		packman.setMnemonic(KeyEvent.VK_R);
		JMenuItem fruit = new JMenuItem("add fruit");
		fruit.setMnemonic(KeyEvent.VK_R);
		JMenuItem saveAsCsv = new JMenuItem("save the game as CSV file");
		saveAsCsv.setMnemonic(KeyEvent.VK_R);
		newGame.add(packman);
		newGame.add(fruit);
		newGame.add(saveAsCsv);
		subMenuDefaultGame.add(newGame);
		mainMenu.add(subMenuDefaultGame);
		// creating menu items
		JMenuItem saveAsKml = new JMenuItem("save as KML");
		saveAsKml.setMnemonic(KeyEvent.VK_R);
		JMenuItem play = new JMenuItem("run movment simulation");
		play.setMnemonic(KeyEvent.VK_R);
		// adding last menu items to the main one
		mainMenu.add(play);
		mainMenu.add(saveAsKml);
		// adding the main menu to the menu bar
		menuBar.add(mainMenu);
		this.setJMenuBar(menuBar);
		this.gameMap = MapFactory.defaultMapInit();
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.gameChangingImage = this.gameMap.getImage();
		this.imagePanel = new ImagePanel(this.gameChangingImage);
		this.getContentPane().add(imagePanel);
		this.pack();
		this.setVisible(true);
		height = this.getHeight() - 22;
		width = this.getWidth() - 79;
	}

}
