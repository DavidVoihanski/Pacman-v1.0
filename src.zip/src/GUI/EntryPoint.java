package GUI;
import java.io.IOException;

import javax.swing.JFrame;


public class EntryPoint 
{
	public static void main(String[] args) throws IOException
	{
		MyFrame mainFrame = new MyFrame();
		
	}
}
